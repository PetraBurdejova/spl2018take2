POLICE_FACILITY_WGS84_readme
 

Column name  (Description)
======================================
PROVIDER = PROVIDER
ADDRESS = ADDRESS
FACI_NAM = FACILITY_NAME
POSTAL_CD = POSTAL_CODE
X = X  (Easting, in MTM NAD 27(3 degree) Projection
)
Y = Y  (Northing, in MTM NAD 27(3 degree) Projection
)
LONGITUDE = LONGITUDE  (Longitude in WGS84 Coordinate System
)
